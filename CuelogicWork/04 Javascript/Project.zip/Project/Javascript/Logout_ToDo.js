
    localStorage.setItem("id",null);

    console.lo

    alert("Loged out Succesfully...");

    window.location.href ="Sign-In_ToDo.html";

